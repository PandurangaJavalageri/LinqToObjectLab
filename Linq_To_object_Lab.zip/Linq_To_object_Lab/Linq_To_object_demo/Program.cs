﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linq_To_object_demo
{
    
        class Program
        {
            static void Main(string[] args)
            {
            //1. List all products whose price in between 50K to 80K
            var PricedList = (from product in ProductsDB.GetProducts() where product.Price <= 80000 && product.Price >= 50000 select product);
            foreach (var item in PricedList)
            {
                Console.WriteLine(item.Price + " " + item.Name + " " + item.Catagory.Name);
            }
            Console.WriteLine();

            //2. Extract all products belongs to Laptops catagory
            var Laptopc = (from product in ProductsDB.GetProducts() where product.Catagory.Name == "Laptops" select product);
            foreach (var item in Laptopc)
            {
                Console.WriteLine(item.Name + " " + item.Catagory.Name);
            }


            //3. Extract/Show Product Name and Catagory Name only
            var products = (from product in ProductsDB.GetProducts() select product);
            foreach (var item in products)
            {
                Console.WriteLine(item.Name + " " + item.Catagory.Name);
            }

            //4. Show the costliest product name 
            var Laptopcostly = ((from product in ProductsDB.GetProducts() orderby product.Price descending select product).Take(1)).ToList();
            Console.WriteLine(Laptopcostly[0].Name);

            //5. Show the cheepest product name and its price
            var Laptopcheap = ((from product in ProductsDB.GetProducts() orderby product.Price select product).Take(1)).ToList();
            Console.WriteLine(Laptopcheap[0].Name + " " + Laptopcheap[0].Price);

            //6. Show the 2nd and 3rd product details
            var prod2and3 = ((from product in ProductsDB.GetProducts() select product).Skip(1).Take(2));
            foreach (var item in prod2and3)
            {
                Console.WriteLine(item.Name + " " + item.Catagory.Name + " " + item.Price);
            }


            //7. List all products in assending order of their price
            var prodact = ((from product in ProductsDB.GetProducts() orderby product.Price select product));
            foreach (var item in prodact)
            {
                Console.WriteLine(item.Name + " " + item.Price);
            }

            //8. Count the no. of products belong to Tablets
            var productTab = ((from product in ProductsDB.GetProducts() where product.Catagory.Name == "Tablets" select product).Count());

            Console.WriteLine(productTab);
            //9. Show which catagory has costly product

            var costlyproductcat = ((from product in ProductsDB.GetProducts() orderby product.Price descending select product.Catagory).Take(1)).ToList();
            Console.WriteLine(costlyproductcat[0].Name);

            //10. Show which catagory has less products
            //var lessprodcategory1= ((from product in ProductsDB.GetProducts() group product by product.Catagory into pc orderby pc.Count()  select pc).First()).ToList();
            var lessprodcategory = ((from product in ProductsDB.GetProducts() group product by product.Catagory into pc orderby pc.Count() select pc).Take(1)).ToList();
           
            foreach (var item in lessprodcategory)
                {
                Console.WriteLine(item.Key.Name);
                }


            //11. Extract the Product Details based on the catagory and show as below
            var laptops = from laptop in ProductsDB.GetProducts() where laptop.Catagory.Name == "Laptops" select laptop;
            foreach (var item in laptops)
            {
                Console.WriteLine(item.Name);
            }
            //Laptops
            //Dell XPS 13

            //HP 430
            // Mobiles
            //IPhone 6

            //Galaxy S6
            //Tablets
            //IPad Pro

            //12. Extract the Product count based on the catagory and show as below
            var lessprodcategory1 = (from product in ProductsDB.GetProducts()
                                    group product by product.Catagory into pc
                                    orderby pc.Count() descending
                                    select (pc, pc.Count()));
            foreach (var item in lessprodcategory1)
            {
                Console.WriteLine(item.pc.Key.Name + " " + item.Item2);
            }


            //Laptops : 2
            //Mobiles: 2
            //Tablets: 1


        }

    }
    class ProductsDB
    {
        public static List<Product> GetProducts()
        {
            Catagory cat1 = new Catagory { CatagoryID = 101, Name = "Laptops" };
            Catagory cat2 = new Catagory { CatagoryID = 201, Name = "Mobiles" };
            Catagory cat3 = new Catagory { CatagoryID = 301, Name = "Tablets" };

            Product p1 = new Product { ProductID = 1, Name = "Dell XPS 13", Catagory = cat1, Price = 90000 };
            Product p2 = new Product { ProductID = 2, Name = "HP 430", Catagory = cat1, Price = 50000 };
            Product p3 = new Product { ProductID = 3, Name = "IPhone 6", Catagory = cat2, Price = 80000 };
            Product p4 = new Product { ProductID = 4, Name = "Galaxy S6", Catagory = cat2, Price = 74000 };
            Product p5 = new Product { ProductID = 5, Name = "IPad Pro", Catagory = cat3, Price = 44000 };

            cat1.Products.Add(p1);
            cat1.Products.Add(p2);
            cat2.Products.Add(p3);
            cat2.Products.Add(p4);
            cat3.Products.Add(p5);

            List<Product> products = new List<Product>();
            products.Add(p1);
            products.Add(p2);
            products.Add(p3);
            products.Add(p4);
            products.Add(p5);

            return products;
        }
    }
    class Product
    {
        public int ProductID { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }
        public Catagory Catagory { get; set; }
    }
    class Catagory
    {
        public int CatagoryID { get; set; }
        public string Name { get; set; }
        public List<Product> Products = new List<Product>();
    }



}



